function sendMessage() {
  const inputField = document.getElementById("user-input");
  const message = inputField.value.trim();
  if (message === "") return;

  addMessage(message, "user");

  // Dummy AI reply (can be improved later)
  setTimeout(() => {
    const reply = generateBotReply(message);
    addMessage(reply, "assistant");
  }, 600);

  inputField.value = "";
}

function addMessage(text, sender) {
  const chatWindow = document.getElementById("chat-window");
  const msgDiv = document.createElement("div");
  msgDiv.classList.add("message", sender);
  msgDiv.textContent = text;
  chatWindow.appendChild(msgDiv);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function generateBotReply(userMsg) {
  // Placeholder logic
  return "I'm a bot clone. You said: " + userMsg;
}
